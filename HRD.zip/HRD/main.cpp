#include <iostream>
#include<graphics.h>
#include<stdio.h>
#include<conio.h>
using namespace std;

int main()
{
   int gm=DETECT,gd;
   initgraph(&gm,&gd,"c:\\TG\\BGI");
   //initwindow(500,500,"happy..",0,0,false,true);
   rectangle(120,350,280,400);
   rectangle(100,400,300,450);
   rectangle(200,50,210,350);
   circle(205,40,10);
   line(212,50,212,350);
   rectangle(210,330,220,340);
   outtextxy(400,200,"press any key to host the flag");
   getch();
   int i=0;
   for(i=0;i<290;i=i+10)
   {
        rectangle(120,350,280,400);
        rectangle(100,400,300,450);
        rectangle(200,50,210,350);
        circle(205,40,10);
        line(212,50,212,350);
        rectangle(210,330-i,220,340-i);
        delay(100);
        clearviewport();
   }
       // FillRect(100,400,300,450,RED);

        rectangle(120,350,280,400);
        rectangle(100,400,300,450);
        rectangle(200,50,210,350);
        circle(205,40,10);
        //line(212,50,212,350);
        setcolor(RED);
        rectangle(210,50,310,70);
        setfillstyle(SOLID_FILL,LIGHTRED);
        floodfill(250,60,RED);
        setcolor(WHITE);
        rectangle(210,70,310,90);
        setfillstyle(SOLID_FILL,WHITE);
        floodfill(250,80,WHITE);
        setcolor(GREEN);
        rectangle(210,90,310,110);
        setfillstyle(SOLID_FILL,GREEN);
        floodfill(250,100,GREEN);
        setcolor(BLUE);
        circle(260,80,10);
        line(250,80,270,80);
        line(260,70,260,90);
        line(255,72,265,88);
        line(251,74,268,86);
        line(252,86,268,74);
        line(255,88,265,72);
        int j=0;
        for(i=0;i<800;i=i+10)
        {
                setcolor(j);
                j++;
                delay(100);
                if(j%10==0)
                    j=0;
                outtextxy(350,150,"Happy Republic Day");
                settextstyle(SANS_SERIF_FONT,HORIZ_DIR,3);
        }


   getch();
   closegraph();

    return 0;
}
